rootProject.name = "flatbuffers-kotlin"
includeBuild("convention-plugins")
include("flatbuffers-kotlin")
include("benchmark")
